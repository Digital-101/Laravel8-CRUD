<!DOCTYPE html>
<html>
<head>
 <title>Send Email Example</title>
</head>
<body>
 
 <h1>This is test mail from </h1>
 <p>Laravel 8 send email example</p>
 
</body>
</html>