@extends('layout')
@section('content')
<div class="container">
        <section class="section-padding">
                <div class="jumbotron text-center">
                <h1>Contact</h1>
                <p>Send message using form below:</p>
                <!-- {{ Html::ul($errors->all(), array('class'=>'errors')) }}
                 -->
                {{ Form::open(['url' => 'contact', 'class' => 'form']) }}
                
                <div>
                {{ Form::label('subject', 'Subject') }}
                {{ Form::text('subject', null, ['class'=>'form-control']) }}
                <br />
                </div>

                <div>
                {{ Form::label('message','Message') }}
                {{ Form::textarea('message', null, ['class'=>'form-control']) }}
                <br />
                </div>
                
               <div class="form-group">
               {{ Form::submit('Send Message', ['class'=>'btn btn-primary']) }}
               </div>
              
                <div>
                {{ Form::close() }}
                </div>
                
                </div>
        </section>
</div>
     
@stop