@extends('layout')
@section('content')
<div class="container">
    <section class="section-padding">
        <div class="jumbotron text-center">
            <h1>About</h1>
            <p>Learn PHP Web Development using Laravel Framework</p>
        </div>
    </section>
@stop