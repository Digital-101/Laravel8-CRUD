@extends('layout')
@section('content')
<section class="header section-padding">>
    <div class="background">&nbsp;</div>
    <div class="container">
        <div class="header-text">
            <h1>Learn PHP: The Easiest Way</h1>
            <p>Laravel Framework for MVC <br/>Web Development</p>
        </div>
    </div>
</section>
</div>
@stop