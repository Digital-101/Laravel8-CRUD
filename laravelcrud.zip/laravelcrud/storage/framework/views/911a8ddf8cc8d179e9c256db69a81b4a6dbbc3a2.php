<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Learn PHP</title>
</head>
<body>
    <h2>Hey</h2>

    <div><?php echo e($details['title']); ?></div>
    <div><?php echo e($details['body']); ?></div>

    <p>Thank You</p>
</body>
</html><?php /**PATH C:\Users\User\Desktop\00APPS\BEND\laravel\resources\views/emails/TestMail.blade.php ENDPATH**/ ?>