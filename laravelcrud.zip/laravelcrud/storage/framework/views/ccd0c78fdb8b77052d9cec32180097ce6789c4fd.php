<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Layout</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

</head>
<body>
    <nav class="navbar navbar-default" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">

            </button>
            <a class="navbar-brand" href="/">Learning PHP</a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

        <a class="navbar-brand" href="/tasks">Tasks</a>
            <ul class="nav navbar-nav navbar-right">
                <li class="active"><a href="./">Home</a></li>
                <li><a href="./about">About</a></li>
                <li><a href="./contact">Contact</a></li>
            </ul>
        </div>
    </nav>
    <?php echo $__env->yieldContent('content'); ?>

    <script src="jquery-3.3.1.js"></script>
    
    <script src="<?php echo e(asset('bootstrap/js/jquery-3.3.1.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
</body>
</html><?php /**PATH H:\11000\ww\laravelbackend\laravelcrud\resources\views/layout.blade.php ENDPATH**/ ?>