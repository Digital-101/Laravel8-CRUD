
<?php $__env->startSection('content'); ?>
<div class="container">
    <section class="section-padding">
        <div class="jumbotron text-center">
            <h1>About</h1>
            <p>Learn PHP Web Development using Laravel Framework</p>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\00APPS\BEND\laravel\resources\views/about.blade.php ENDPATH**/ ?>