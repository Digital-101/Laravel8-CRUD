
<?php $__env->startSection('content'); ?>
<div class="container">
        <section class="section-padding">
                <div class="jumbotron text-center">
                <h1>Contact</h1>
                <p>Send message using form below:</p>
                <!-- <?php echo e(Html::ul($errors->all(), array('class'=>'errors'))); ?>

                 -->
                <?php echo e(Form::open(['url' => 'contact', 'class' => 'form'])); ?>

                
                <div>
                <?php echo e(Form::label('subject', 'Subject')); ?>

                <?php echo e(Form::text('subject', null, ['class'=>'form-control'])); ?>

                <br />
                </div>

                <div>
                <?php echo e(Form::label('message','Message')); ?>

                <?php echo e(Form::textarea('message', null, ['class'=>'form-control'])); ?>

                <br />
                </div>
                
               <div class="form-group">
               <?php echo e(Form::submit('Send Message', ['class'=>'btn btn-primary'])); ?>

               </div>
              
                <div>
                <?php echo e(Form::close()); ?>

                </div>
                
                </div>
        </section>
</div>
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\00APPS\BEND\laravel\resources\views/contact.blade.php ENDPATH**/ ?>