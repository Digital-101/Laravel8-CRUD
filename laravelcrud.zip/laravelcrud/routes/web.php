<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TaskController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', function()
{
    return View::make('home');
});

Route::get('/about', function()
{
    return View::make('about');
});

Route::get('/contact', function()
{
    return View::make('contact');
});

//Add Validation
Route::post('contact', function()
{
    $data = Request::all();
    $rules = array(
        'subject' => 'required',
        'message' => 'required'
    );

    $validator = Validator::make($data, $rules);

    if ($validator -> fails()) {
        return Redirect::to('contact')->withErrors($validator)->withInput();
    }
});

Route::get('send-mail', function() {
    
    $details = [
        'title' => 'Mail From PHPLearn.com',
        'body' => 'This is for testing email using smtp'
    ];

    \Mail::to('mk9digital13@gmail.com')->send(new \App\Mail\TestMail($details));

    dd("Email is Sent.");
});

use App\Http\Controllers\SendEmailController;

Route::get('send-email', [SendEmailController::class, 'index']);

Route::get('/sendfeedback', 'App\Http\Controllers\SendFeedBackController@index');

//crud
Route::resource('tasks', TaskController::class);